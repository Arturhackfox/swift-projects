import UIKit

class Vehicle {
   private(set) var maxSpeed: Int
   private(set) var color: String
   private(set) var weightInKg: Int
    
    init(maxSpeed: Int, color: String, weightInKg: Int) {
        self.maxSpeed = maxSpeed
        self.color = color
        self.weightInKg = weightInKg
    }
    
    func changeMaxSpeed(to number: Int) {
        maxSpeed = number
    }
    func changeColor(to color: String) {
        self.color = color
    }
    func changeWeight(to weight: Int) {
        weightInKg = weight
    }
}

class Car: Vehicle {
    private(set) var brand: String
    private(set) var price: Int
    private(set) var isElectrical: Bool
    
    init(brand: String, price: Int, isElectrical: Bool, maxSpeed: Int, color: String, weightInKg: Int) {
        self.brand = brand
        self.price = price
        self.isElectrical = isElectrical
        super.init(maxSpeed: maxSpeed, color: color, weightInKg: weightInKg)
    }
    
    func describeCarBrand() {
        print("My car brand is \(brand)")
    }
    func describeCarPrice() {
        print("My car price is \(price)$")
    }
    func describeCarType() {
        print("My car  is \(isElectrical ? "is electrical" : "not electrical")")
    }
}

class Bike: Vehicle {
    private(set) var brand: String
    private(set) var wheelsCount: Int
    private(set) var isHelmetRequired: Bool
    
    init(brand: String, wheelsCount: Int, isHelmetRequired: Bool, maxSpeed: Int, color: String, weightInKg: Int) {
        self.brand = brand
        self.wheelsCount = wheelsCount
        self.isHelmetRequired = isHelmetRequired
        super.init(maxSpeed: maxSpeed, color: color, weightInKg: weightInKg)
    }
    
    func describeBikeBrand() {
        print("My bike brand is \(brand)")
    }
    func describeBikeWheelCount() {
        print("My bike has \(wheelsCount) wheels.")
    }
    func showHelmetRules() {
        print("In my city i \(isHelmetRequired ? "must wear helmet" : "can ride without helmet on")")
    }
}

class Airplane: Vehicle {
    private(set) var brandName: String
    private(set) var passengerSeats: Int
    private(set) var isBussinesClass: Bool
    
    init(brandName: String, passengerSeats: Int, isBussinesClass: Bool, maxSpeed: Int, color: String, weightInKg: Int) {
        self.brandName = brandName
        self.passengerSeats = passengerSeats
        self.isBussinesClass = isBussinesClass
        super.init(maxSpeed: maxSpeed, color: color, weightInKg: weightInKg)
    }
    
    func describeAirplaneBrand() {
        print("Our airplane brand is \(brandName)")
    }
    func countAirPlaneSeats() {
        print("Out airplane has \(passengerSeats) seats.")
    }
    func answerIsThatBussinesClass() {
        print("This plane is \(isBussinesClass ? "Business class." : "not bussines class.")")
    }
}

let car = Car(brand: "Toyota", price: 23000, isElectrical: false, maxSpeed: 220, color: "Black", weightInKg: 1200)
let bike = Bike(brand: "Vogel", wheelsCount: 4, isHelmetRequired: false, maxSpeed: 25, color: "Blue", weightInKg: 2)
let airplane = Airplane(brandName: "Boeing", passengerSeats: 120, isBussinesClass: false, maxSpeed: 1100, color: "White", weightInKg: 3200)
car.describeCarType()
car.describeCarBrand()
car.describeCarPrice()

bike.describeBikeBrand()
bike.describeBikeWheelCount()
bike.showHelmetRules()

airplane.answerIsThatBussinesClass()
airplane.countAirPlaneSeats()
airplane.describeAirplaneBrand()
