import Foundation

// Task 1
struct Vehicle {
    static let consumption = 16.5
}

let consumption = Vehicle.consumption

struct Car {
    let model: String
    let coastGazoline: Double

    func calculationTotalTrackExpenses(distance: Double) -> Int {
        return Int((consumption / 100) * (distance * coastGazoline))
    }
}

struct TotalCoastInfo {
    let peopleCount: Int
    let travelDays: Int
    let smallCoastOneDay: Double
    let coastOneNightInHotel: Double

    func calculationFoodExpenses() -> Double {
        return ((smallCoastOneDay + coastOneNightInHotel) + (Double(travelDays) * Double(peopleCount)))
    }
}

class City {
    let name: String
    let population: Int
    let info: TotalCoastInfo
    let car: Car

    init(name: String, population: Int, info: TotalCoastInfo, car: Car) {
        self.name = name
        self.population = population
        self.info = info
        self.car = car
    }

    func cityDescription() -> String {
        "Население города \(name) на 2023 год составляет \(population) человек."
    }
}

class People {
    var name: String
    var age: Int

    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

class Almaty: City {

    override init(name: String, population: Int, info: TotalCoastInfo, car: Car) {
        super.init(name: name, population: population, info: info, car: car)
    }

    func aboutAlmaty(cityName: String) -> String {
        "Решили как то поехать с другом по работе в город \(cityName). Поедим на моей машине \(car.model)."
    }
}

class Karaganda: City {
    let distance: Double

    init (distance: Double, name: String, population: Int, info: TotalCoastInfo, car: Car) {
        self.distance = distance
        super.init(name: name, population: population, info: info, car: car)
    }

    func aboutKaraganda() -> String {
        "Первый город который мы будем проезжать это \(name). Расстояние между начальной отправной точкой составит \(distance) км. Стоимость на топлива составит: \(car.calculationTotalTrackExpenses(distance: distance)) тенге."
    }
}

class Pavlodar: City {
    let foodExpenses: Double
    let distance: Double
    let prevCity: String

    init(foodExpenses: Double, distance: Double, prevCity: String, name: String, population: Int, info: TotalCoastInfo, car: Car) {
        self.foodExpenses = foodExpenses
        self.distance = distance
        self.prevCity = prevCity
        super.init(name: name, population: population, info: info, car: car)
    }

    func aboutPavlodar() -> String {
        "Третий город в который мы приедим это \(name). Это наша конечная точка. Расстояние между \(prevCity) и \(name) составляет: \(distance) км. После прибытия в точку назначения, мы заселимся в местную гостиницу, стоимость за одну ночь составляет: \(info.coastOneNightInHotel) тенге. Стоимость на топлива составит: \(car.calculationTotalTrackExpenses(distance: distance)) тенге."
    }
}

class Alex: People {

    let almatyCity: Almaty
    let pavlodarCity: Pavlodar
    let karagandaCity: Karaganda

    init(almatyCity: Almaty, pavlodarCity: Pavlodar, karagandaCity: Karaganda, name: String, age: Int) {
        self.almatyCity = almatyCity
        self.pavlodarCity = pavlodarCity
        self.karagandaCity = karagandaCity
        super.init(name: name, age: age)
    }

    func aboutMe() {
        print("Меня зовут \(name). Мне \(age) лет. \(almatyCity.aboutAlmaty(cityName: pavlodarCity.name)) \(karagandaCity.aboutKaraganda()) \(pavlodarCity.aboutPavlodar()) Итого за двоих на еду выйдет: \(pavlodarCity.info.calculationFoodExpenses()) тенге")
    }
}

let alex = Alex(
    almatyCity: Almaty(name: "Алматы", population: 2211, info: TotalCoastInfo(peopleCount: 2, travelDays: 10, smallCoastOneDay: 0.0, coastOneNightInHotel: 0.0), car: Car(model: "Audi Q8", coastGazoline: 250.0)),
    pavlodarCity: Pavlodar(foodExpenses: 45000.0, distance: 442.7, prevCity: "Караганда", name: "Павлодар", population: 332_062, info: TotalCoastInfo(peopleCount: 2, travelDays: 10, smallCoastOneDay: 2000.0, coastOneNightInHotel: 22000.0),  car: Car(model: "Audi Q8", coastGazoline: 320.0)),
    karagandaCity: Karaganda(distance: 1005.0, name: "Караганда", population: 515_835, info: TotalCoastInfo(peopleCount: 2, travelDays: 10, smallCoastOneDay: 20000.0, coastOneNightInHotel: 0.0),  car: Car(model: "Audi Q8", coastGazoline: 250.0)),
    name: "Алексей",
    age: 37
)
alex.aboutMe()
